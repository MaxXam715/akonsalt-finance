const version = document.querySelector("head meta[name='version']").getAttribute("content");
const global_phone = "+79266694447";
const global_email = "mail@you-finances.ru";
const legal_IP = "Кешишян Андраник Саркисович";
const legal_INN = "610601804601";
const legal_OGRNIP = "323619600191282";
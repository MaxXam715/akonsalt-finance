import FirstScreen from "./FirstScreen.js";
import TheyCooperateWithMe from "./TheyCooperateWithMe.js";
import DocumentsAndCertificates from "./DocumentsAndCertificates.js";

export default function About() {
    FirstScreen();
    TheyCooperateWithMe();
    DocumentsAndCertificates();
}
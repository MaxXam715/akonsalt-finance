const version = document.querySelector("head meta[name='version']").getAttribute("content");
const global_phone = "+79264447789";
const legal_IP = "Кешишян Андраник Саркисович";
const legal_INN = "610601804601";
const legal_OGRNIP = "323619600191282";